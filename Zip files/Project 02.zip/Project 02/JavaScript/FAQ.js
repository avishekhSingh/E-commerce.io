$(".btn1").mouseenter(function(){
  $(".btn1").text("-");
  $(".text1").append(" Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, iusto fuga error blanditiis voluptas id eaque, temporibus deleniti quas aliquid sunt inventore dolor exercitationem, modi tempora nisi illum ex nemo consequuntur ut recusandae at quibusdam. Soluta sit deserunt laudantium illo esse placeat ut, corrupti, autem incidunt sequi nihil dolorum asperiores modi saepe aspernatur? Accusamus, maxime.")
});
$(".btn1").mouseleave(function(){
  $(".btn1").text("+")
  $(".text1").empty();
});
$(".btn2").mouseenter(function(){
  var btn2= $(".btn2");
  $(".btn2").text("-")
  $(".text2").append(" Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, iusto fuga error blanditiis voluptas id eaque, temporibus deleniti quas aliquid sunt inventore dolor exercitationem, modi tempora nisi illum ex nemo consequuntur ut recusandae at quibusdam. Soluta sit deserunt laudantium illo esse placeat ut, corrupti, autem incidunt sequi nihil dolorum asperiores modi saepe aspernatur? Accusamus, maxime.")
});
 $(".btn2").mouseleave(function(){
  $(".btn2").text("+")
  $(".text2").empty();
});
$(".btn3").mouseenter(function(){
  $(".btn3").text("-")
  $(".text3").append(" Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, iusto fuga error blanditiis voluptas id eaque, temporibus deleniti quas aliquid sunt inventore dolor exercitationem, modi tempora nisi illum ex nemo consequuntur ut recusandae at quibusdam. Soluta sit deserunt laudantium illo esse placeat ut, corrupti, autem incidunt sequi nihil dolorum asperiores modi saepe aspernatur? Accusamus, maxime.")
});
 $(".btn3").mouseleave(function(){
  $(".btn3").text("+")
  $(".text3").empty();
});
$(".btn4").mouseenter(function(){
  $(".btn4").text("-")
  $(".text4").append(" Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, iusto fuga error blanditiis voluptas id eaque, temporibus deleniti quas aliquid sunt inventore dolor exercitationem, modi tempora nisi illum ex nemo consequuntur ut recusandae at quibusdam. Soluta sit deserunt laudantium illo esse placeat ut, corrupti, autem incidunt sequi nihil dolorum asperiores modi saepe aspernatur? Accusamus, maxime.")
});
 $(".btn4").mouseleave(function(){
  $(".btn4").text("+")
  $(".text4").empty();
});
$(".btn5").mouseenter(function(){
  $(".btn5").text("-")
  $(".text5").append(" Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, iusto fuga error blanditiis voluptas id eaque, temporibus deleniti quas aliquid sunt inventore dolor exercitationem, modi tempora nisi illum ex nemo consequuntur ut recusandae at quibusdam. Soluta sit deserunt laudantium illo esse placeat ut, corrupti, autem incidunt sequi nihil dolorum asperiores modi saepe aspernatur? Accusamus, maxime.")
});
 $(".btn5").mouseleave(function(){
  $(".btn5").text("+")
  $(".text5").empty();
});
$(".btn6").mouseenter(function(){
  $(".btn6").text("-")
  $(".text6").append(" Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, iusto fuga error blanditiis voluptas id eaque, temporibus deleniti quas aliquid sunt inventore dolor exercitationem, modi tempora nisi illum ex nemo consequuntur ut recusandae at quibusdam. Soluta sit deserunt laudantium illo esse placeat ut, corrupti, autem incidunt sequi nihil dolorum asperiores modi saepe aspernatur? Accusamus, maxime.")
});
 $(".btn6").mouseleave(function(){
  $(".btn6").text("+")
  $(".text6").empty();
});
$(".btn7").mouseenter(function(){
  $(".btn7").text("-")
  $(".text7").append(" Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, iusto fuga error blanditiis voluptas id eaque, temporibus deleniti quas aliquid sunt inventore dolor exercitationem, modi tempora nisi illum ex nemo consequuntur ut recusandae at quibusdam. Soluta sit deserunt laudantium illo esse placeat ut, corrupti, autem incidunt sequi nihil dolorum asperiores modi saepe aspernatur? Accusamus, maxime.")
});
 $(".btn7").mouseleave(function(){
  $(".btn7").text("+")
  $(".text7").empty();
});
$(".btn8").mouseenter(function(){
  $(".btn8").text("-")
  $(".text8").append(" Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, iusto fuga error blanditiis voluptas id eaque, temporibus deleniti quas aliquid sunt inventore dolor exercitationem, modi tempora nisi illum ex nemo consequuntur ut recusandae at quibusdam. Soluta sit deserunt laudantium illo esse placeat ut, corrupti, autem incidunt sequi nihil dolorum asperiores modi saepe aspernatur? Accusamus, maxime.")
});
 $(".btn8").mouseleave(function(){
  $(".btn8").text("+")
  $(".text8").empty();
});